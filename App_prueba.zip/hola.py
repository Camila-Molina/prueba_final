from flask import Flask
application = Flask(__name__)


@application.route('/')
def hola():
    return 'Hola mundo'